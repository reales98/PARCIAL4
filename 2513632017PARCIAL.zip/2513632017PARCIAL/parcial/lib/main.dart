import 'package:flutter/material.dart';  
import 'package:google_maps_flutter/google_maps_flutter.dart';  
  
void main() => runApp(MyApp());  
  
class MyApp extends StatefulWidget {  
  @override  
  _MyAppState createState() => _MyAppState();  
}  
  
class _MyAppState extends State<MyApp> {  
  GoogleMapController mapController;  
  static final LatLng _center = const LatLng(13.345247,-88.437405); 
  static final LatLng _center = const LatLng(13.467346,-88.149988);
  static final LatLng _center = const LatLng(13.328304,-87.841761); 
  final Set<Marker> _markers = {};  
  LatLng _currentMapPosition = _center;  
  
  void _onAddMarkerButtonPressed() {  
    setState(() {  
      _markers.add(Marker(  
        markerId: MarkerId(_currentMapPosition.toString()),  
        position: _currentMapPosition,  
        infoWindow: InfoWindow(  
          title: 'TE LO LLEVO SAN MIGUEL ',  
          snippet: 'BIENVENIDOS A NUESTROS BONITOS DEPARTAMENTOS'  
        
        void _onAddMarkerButtonPressed() {  
  setState(() {  
    _markers.add(Marker(  
      markerId: MarkerId(_lastMapPosition.toString()),  
      position: _currentMapPosition,  
      infoWindow: InfoWindow(  
        title: 'Te lo llevo USULUTAN' 
      ),  

      void _onAddMarkerButtonPressed() {  
  setState(() {  
    _markers.add(Marker(  
      markerId: MarkerId(_lastMapPosition.toString()),  
      position: _currentMapPosition,  
      infoWindow: InfoWindow(  
        title: 'TE LO LLEVO MORAZAN'  
      ),  

      void _onAddMarkerButtonPressed() {  
  setState(() {  
    _markers.add(Marker(  
      markerId: MarkerId(_lastMapPosition.toString()),  
      position: _currentMapPosition,  
      infoWindow: InfoWindow(  
        title: 'TE LO LLEVO LA UNION'  
      ),  
      icon: BitmapDescriptor. defaultMarkerWithHue(BitmapDescriptor.hueViolet)  
    ));  
  });  
}  
      icon: BitmapDescriptor. defaultMarkerWithHue(BitmapDescriptor.hueViolet)  
    ));  
  });  
}  
      icon: BitmapDescriptor. defaultMarkerWithHue(BitmapDescriptor.hueViolet)  
    ));  
  });  
}  

        ),  
        icon: BitmapDescriptor.defaultMarker,  
      ));  
    });  
  }  
  
  void _onCameraMove(CameraPosition position) {  
    _currentMapPosition = position.target;  
  }  
  
  void _onMapCreated(GoogleMapController controller) {  
    mapController = controller;  
  }  
  
  @override  
  Widget build(BuildContext context) {  
    return MaterialApp(  
      home: Scaffold(  
        appBar: AppBar(  
          title: Text('VISTA PREVIA DE MAPAS'),  
          backgroundColor: Colors.blue,  
        ),  
        body: Stack(  
          children: <Widget>[  
            GoogleMap(  
              onMapCreated: _onMapCreated,  
              initialCameraPosition: CameraPosition(  
                target: _center,  
                zoom: 10.0,  
              ),  
              markers: _markers,  
              onCameraMove: _onCameraMove  
            ),  
            Padding(  
              padding: const EdgeInsets.all(14.0),  
              child: Align(  
                alignment: Alignment.topRight,  
                child: FloatingActionButton(  
                  onPressed: _onAddMarkerButtonPressed,  
                  materialTapTargetSize: MaterialTapTargetSize.padded,  
                  backgroundColor: Colors.green,  
                  child: const Icon(Icons.map, size: 90.0),  
                ),  
    );  
  }  
}  
